---
name: 'Epic'
about: 'Create an epic'
---

## Description
<!--- Provide a summary of what the epic should accomplish -->

## Proposal
<!--- Link to the proposal doc --->

## Spec
<!--- Link to the spec doc -->

## Issues
<!--- Link(s) to sensu-go GH issues --->
<!--- Link(s) to sensu-enterprise-go GH issues --->
<!--- Link(s) to sensu-go-qa-crucible GH issues --->
<!--- Link(s) to sensu-staging GH issues --->
<!--- Link(s) to sensu-docs GH issues --->