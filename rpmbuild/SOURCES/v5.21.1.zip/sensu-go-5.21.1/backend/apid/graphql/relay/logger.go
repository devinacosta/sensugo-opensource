package relay

import "github.com/sirupsen/logrus"

var logger = logrus.WithField("component", "graphql/relay")
