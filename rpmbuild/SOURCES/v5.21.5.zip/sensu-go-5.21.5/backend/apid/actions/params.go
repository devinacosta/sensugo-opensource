package actions

// QueryParams keys inwhich to filter results of query.
type QueryParams map[string]string
